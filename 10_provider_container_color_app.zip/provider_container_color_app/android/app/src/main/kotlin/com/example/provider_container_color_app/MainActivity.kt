package com.example.provider_container_color_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
