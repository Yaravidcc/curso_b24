import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider_container_color_app/widgets/widgets.dart';

import '../providers/providers.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text('Uso de Provider'),
      ),
      body: Center(
        child: Column(
          children: [
            _ColorSlider(
              value: context.watch<ColorProvider>().red,
              // onChanged: (value) => context.read<ColorProvider>().changeRed(value),
              onChanged: context.read<ColorProvider>().changeRed,
            ),
            _ColorSlider(
              value: context.watch<ColorProvider>().green,
              // onChanged: (value) => context.read<ColorProvider>().changeGreen(value),
              onChanged: context.read<ColorProvider>().changeGreen,
            ),
            _ColorSlider(
              value: context.watch<ColorProvider>().blue,
              // onChanged: (value) => context.read<ColorProvider>().changeBlue(value),
              onChanged: context.read<ColorProvider>().changeBlue,
            ),
            _ColorContainer(
              color: Color.fromRGBO(
                context.watch<ColorProvider>().red.toInt(),
                context.watch<ColorProvider>().green.toInt(),
                context.watch<ColorProvider>().blue.toInt(),
                1,
              ),
            ),
            const SizedBox(
              height: 12,
            ),
            AppFilledButton(
              color: Color.fromRGBO(
                context.watch<ColorProvider>().red.toInt(),
                context.watch<ColorProvider>().green.toInt(),
                context.watch<ColorProvider>().blue.toInt(),
                1,
              ),
              onPressed: () {},
              child: const Text('Aceptar'),
            )
          ],
        ),
      ),
    );
  }
}

class _ColorContainer extends StatelessWidget {
  final Color color;

  const _ColorContainer({required this.color});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24.0),
      child: Container(
        width: double.infinity,
        height: 150,
        color: color,
      ),
    );
  }
}

class _ColorSlider extends StatelessWidget {
  final double value;
  final void Function(double) onChanged;

  const _ColorSlider({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 12.0),
      child: Row(
        children: [
          Text(
            'Valor: ${value.round().toString()}',
            style: GoogleFonts.dynaPuff(),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Slider(
              value: value,
              max: 255,
              divisions: 5,
              label: value.round().toString(),
              onChanged: onChanged,
            ),
          ),
        ],
      ),
    );
  }
}
