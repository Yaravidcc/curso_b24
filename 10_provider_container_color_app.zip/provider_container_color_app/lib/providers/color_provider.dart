import 'package:flutter/material.dart';

class ColorProvider extends ChangeNotifier {
  late double _red;
  late double _green;
  late double _blue;

  ColorProvider({double red = 0, double green = 0, double blue = 0}) {
    _red = red;
    _green = green;
    _blue = blue;
  }

  double get red => _red;
  double get blue => _blue;
  double get green => _green;

  void changeRed(double red) {
    _red = red;
    notifyListeners();
  }

  void changeGreen(double green) {
    _green = green;
    notifyListeners();
  }

  void changeBlue(double blue) {
    _blue = blue;
    notifyListeners();
  }
}
